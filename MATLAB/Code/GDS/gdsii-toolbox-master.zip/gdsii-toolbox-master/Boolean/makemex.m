%
% script to make .mex files
%
mex -O poly_boolmex.cpp clipper.cpp
